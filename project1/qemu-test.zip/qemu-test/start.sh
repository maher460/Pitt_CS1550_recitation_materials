#!/bin/sh
qemu-system-i386 -hda tty.qcow2 -boot c
